<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "computer_lab_inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


// Fetching items from the database
$sql = "SELECT * FROM inventory";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Computer Lab Inventory</title>
</head>
<body>

<h2>Computer Lab Inventory</h2>

<!-- Display Items -->
<h3>Inventory List</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Item Name</th>
        <th>Category</th>
        <th>Quantity</th>
        <th>Date Added</th>
        <th>Actions</th>
    </tr>

    <?php
    // Fetching items from the database
    $sql = "SELECT * FROM inventory";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["id"] . "</td>
                    <td>" . $row["item_name"] . "</td>
                    <td>" . $row["category"] . "</td>
                    <td>" . $row["quantity"] . "</td>
                    <td>" . $row["date_added"] . "</td>
                    <td class='action-btns'>
                        <button class='edit-btn' onclick='openEditModal(" . $row["id"] . ", \"" . $row["item_name"] . "\", \"" . $row["category"] . "\", " . $row["quantity"] . ")'>Edit</button>
                        <button class='remove-btn' onclick='confirmRemove(" . $row["id"] . ")'>Remove</button>
                    </td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No items found</td></tr>";
    }
    ?>
    
</table>
</body>
</html>
