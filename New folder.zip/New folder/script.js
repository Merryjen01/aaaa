document.getElementById('mr-saraza-btn').addEventListener('click', function() {
  const balloon = document.createElement('div');
  balloon.classList.add('balloon');
  document.body.appendChild(balloon);

  setTimeout(() => {
    balloon.remove();
  }, 3000);
});